import AVKit
import SwiftUI
import UIKit

struct VideoPlayer: UIViewRepresentable {
    func makeUIView(context: Context) -> VideoPlayerUIKit {
        VideoPlayerUIKit()
    }
    func updateUIView(_ uiView: VideoPlayerUIKit, context: Context) {}
    typealias UIViewType = VideoPlayerUIKit
}

class VideoPlayerUIKit: UIView {
    
    var avPlayer: AVQueuePlayer!
    var videoName: String = "problems"
    
    override func draw(_ rect: CGRect) {
        let filepath: String? = Bundle.main.path(forResource: "\(videoName)", ofType: "mov")
        let fileURL = URL.init(fileURLWithPath: filepath!)
        avPlayer = AVQueuePlayer(url: fileURL)
        let playerLayer = AVPlayerLayer(player: avPlayer)
        playerLayer.frame = bounds
        layer.insertSublayer(playerLayer, at: 0)
        avPlayer.isMuted = true
        avPlayer.play()
    }
    
}

