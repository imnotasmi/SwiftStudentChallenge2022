import SwiftUI
struct Theme {
    static let themeColor: Color =  Color(red: 250/255, green: 242/255, blue: 233/255)
    static let themePink: Color = Color(red: 241/255, green: 176/255, blue: 206/255)
    static let themeBlack: Color = Color(red: 0, green: 0, blue: 0)
}
