
import UIKit
import AVFoundation
import AVKit
import SwiftUI

class FoodViewController: UIViewController {
    
    // MARK: - Oultes
    
    private lazy var viewVideo = UIView()
    private lazy var foodSecond = FoodView()
    private lazy var foodThird = FoodView()
    private lazy var foodFourth = FoodView()
    private lazy var foodFivth = FoodView()
    private lazy var foodSixth = FoodView()
    private lazy var foodOne = FoodView()
    private lazy var viewGesture = UIView()
    private lazy var view2 = UIView()
    private lazy var headLabel = UILabel()
    private lazy var instrucLabel = UILabel()
    private lazy var letsFeedBtn = UIButton(type: .system)
    private lazy var viewGuide = UIView()
    private lazy var imageView = UIImageView()
    private lazy var cheersLabel = UILabel()
    private lazy var jobdoneLabel = UILabel()
    private lazy var nextBtn = UIButton(type: .system)
    private lazy var stackView = UIStackView()
    private lazy var viewWinning = UIView()
    
    // MARK: - Properties
    
    var tralY: Float = 0
    var winingCompletiom: ()-> Void = {}
    var goodFoodCount: Int = 0 {
        didSet  {
            if goodFoodCount == 3 {
                viewVideo.isHidden = true
                viewWinning.isHidden = false
            }
        }
    }
    var avPlayer: AVQueuePlayer!
    var currentFood: FoodView?
    var isCurrentFood = false
    var foodArray = [FoodView]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupLayout()
        initialSetup()
    }
    
    private func setupUI() {
        viewVideo.backgroundColor = .cyan
        view.addSubview(viewVideo)
        view.addSubview(viewGesture)
        view.addSubview(view2)
        view.addSubview(headLabel)
        view.addSubview(viewGuide)
        view.addSubview(viewWinning)
        
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.backgroundColor = UIColor(red: 0.97647058959999999, green: 0.94901961089999998, blue: 0.91764706370000004, alpha: 1)
        view.frame = CGRect(x: 0, y: 0, width: 414, height: 896)
        
        viewWinning.addSubview(stackView)
        
        viewWinning.backgroundColor = UIColor(white: 0, alpha: 0.050000000000000003)
        viewWinning.isHidden = true
        viewWinning.translatesAutoresizingMaskIntoConstraints = false
        
        stackView.addArrangedSubview(imageView)
        stackView.addArrangedSubview(cheersLabel)
        stackView.addArrangedSubview(jobdoneLabel)
        stackView.addArrangedSubview(nextBtn)
        
        stackView.alignment = .center
        stackView.axis = .vertical
        stackView.spacing = 17
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        nextBtn.backgroundColor = UIColor(red: 0.67450982329999998, green: 0.48235297199999999, blue: 0.57254904510000004, alpha: 1)
        nextBtn.contentVerticalAlignment = .center
        nextBtn.tintColor = UIColor.white
        nextBtn.titleLabel?.lineBreakMode = .byTruncatingMiddle
        nextBtn.translatesAutoresizingMaskIntoConstraints = false
        nextBtn.setTitle("Let's move to next step!", for: .normal)
        if #available(iOS 15.0, *) {
            nextBtn.configuration = UIButton.Configuration.plain()
        }
        if #available(iOS 15.0, *) {
            nextBtn.configuration?.title = "Let's move to next step!"
        }
        
        nextBtn.addTarget(self, action: #selector(self.actionNextStep(_:)), for: .touchUpInside)
        jobdoneLabel.contentMode = .left
        jobdoneLabel.font = UIFont.systemFont(ofSize: 20)
        jobdoneLabel.setContentHuggingPriority(UILayoutPriority(rawValue: 251), for: .horizontal)
        jobdoneLabel.setContentHuggingPriority(UILayoutPriority(rawValue: 251), for: .vertical)
        jobdoneLabel.text = "You have fed all healthy food"
        jobdoneLabel.textAlignment = .natural
        jobdoneLabel.textColor = UIColor.black
        jobdoneLabel.translatesAutoresizingMaskIntoConstraints = false
        
        cheersLabel.contentMode = .left
        cheersLabel.font = UIFont.systemFont(ofSize: 50, weight: .heavy)
        cheersLabel.setContentHuggingPriority(UILayoutPriority(rawValue: 251), for: .horizontal)
        cheersLabel.setContentHuggingPriority(UILayoutPriority(rawValue: 251), for: .vertical)
        cheersLabel.text = "Good Job"
        cheersLabel.textAlignment = .natural
        cheersLabel.textColor = UIColor.black
        cheersLabel.translatesAutoresizingMaskIntoConstraints = false
        
        imageView.clipsToBounds = true
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: "goodJob")
        imageView.setContentHuggingPriority(UILayoutPriority(rawValue: 251), for: .horizontal)
        imageView.setContentHuggingPriority(UILayoutPriority(rawValue: 251), for: .vertical)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        
        viewGuide.addSubview(instrucLabel)
        viewGuide.addSubview(letsFeedBtn)
        
        viewGuide.backgroundColor = UIColor(white: 0, alpha: 0.10000000000000001)
        viewGuide.translatesAutoresizingMaskIntoConstraints = false
        
        letsFeedBtn.backgroundColor = UIColor(red: 0.6784313917, green: 0.48627454040000001, blue: 0.57647061349999995, alpha: 1)
        letsFeedBtn.contentVerticalAlignment = .center
        letsFeedBtn.tintColor = UIColor(white: 0.98421556122448983, alpha: 1)
        letsFeedBtn.titleLabel?.lineBreakMode = .byTruncatingMiddle
        letsFeedBtn.translatesAutoresizingMaskIntoConstraints = false
        letsFeedBtn.setTitle("Let's feed", for: .normal)
        if #available(iOS 15.0, *) {
            letsFeedBtn.configuration = UIButton.Configuration.plain()
        }
        if #available(iOS 15.0, *) {
            letsFeedBtn.configuration?.title = "Let's feed"
        }
        letsFeedBtn.addTarget(self, action: #selector(self.actionLetsFeed(_:)), for: .touchUpInside)
        instrucLabel.contentMode = .left
        instrucLabel.font = UIFont.systemFont(ofSize: 22)
        instrucLabel.setContentHuggingPriority(UILayoutPriority(rawValue: 251), for: .horizontal)
        instrucLabel.setContentHuggingPriority(UILayoutPriority(rawValue: 251), for: .vertical)
        instrucLabel.text = "Drag good food to Anna's mouth"
        instrucLabel.textAlignment = .natural
        instrucLabel.textColor = UIColor.black
        instrucLabel.translatesAutoresizingMaskIntoConstraints = false
        
        headLabel.contentMode = .left
        headLabel.font = UIFont.systemFont(ofSize: 41, weight: .heavy)
        headLabel.numberOfLines = 0
        headLabel.setContentHuggingPriority(UILayoutPriority(rawValue: 251), for: .horizontal)
        headLabel.setContentHuggingPriority(UILayoutPriority(rawValue: 251), for: .vertical)
        headLabel.text = "Feed Healthy Food To Anna"
        headLabel.textAlignment = .center
        headLabel.textColor = UIColor.black
        headLabel.translatesAutoresizingMaskIntoConstraints = false
        
        view2.backgroundColor = UIColor(red: 0.67450982329999998, green: 0.48235297199999999, blue: 0.57254904510000004, alpha: 1)
        view2.translatesAutoresizingMaskIntoConstraints = false
        
        viewGesture.addSubview(foodSecond)
        viewGesture.addSubview(foodThird)
        viewGesture.addSubview(foodFourth)
        viewGesture.addSubview(foodFivth)
        viewGesture.addSubview(foodSixth)
        viewGesture.addSubview(foodOne)
        
        viewGesture.backgroundColor = UIColor(white: 0, alpha: 0)
        viewGesture.translatesAutoresizingMaskIntoConstraints = false
        
        foodOne.backgroundColor = UIColor.systemPink
        foodOne.tag = 1
        foodOne.translatesAutoresizingMaskIntoConstraints = false
        
        foodSixth.backgroundColor = UIColor.systemPink
        foodSixth.translatesAutoresizingMaskIntoConstraints = false
        
        foodFivth.backgroundColor = UIColor.systemPink
        foodFivth.translatesAutoresizingMaskIntoConstraints = false
        
        foodFourth.backgroundColor = UIColor.systemPink
        foodFourth.translatesAutoresizingMaskIntoConstraints = false
        
        foodThird.backgroundColor = UIColor.systemPink
        foodThird.tag = 3
        foodThird.translatesAutoresizingMaskIntoConstraints = false
        
        foodSecond.backgroundColor = UIColor.systemPink
        foodSecond.tag = 2
        foodSecond.translatesAutoresizingMaskIntoConstraints = false
        
        viewVideo.backgroundColor = UIColor(white: 0, alpha: 0)
        viewVideo.translatesAutoresizingMaskIntoConstraints = false
    }
    
    private func setupLayout() {
        
        viewVideo.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor).isActive = true
        viewWinning.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        view2.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        headLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor).isActive = true
        viewWinning.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        view.bottomAnchor.constraint(equalTo: view2.bottomAnchor).isActive = true
        view2.topAnchor.constraint(equalTo: viewGesture.bottomAnchor).isActive = true
        viewGesture.topAnchor.constraint(equalTo: viewVideo.centerYAnchor).isActive = true
        view.safeAreaLayoutGuide.trailingAnchor.constraint(equalTo: viewGuide.trailingAnchor).isActive = true
        viewWinning.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor).isActive = true
        view.bottomAnchor.constraint(equalTo: viewGuide.bottomAnchor).isActive = true
        headLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        view2.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor).isActive = true
        viewVideo.heightAnchor.constraint(equalTo: viewGesture.heightAnchor, multiplier: 0.9).isActive = true
        viewGuide.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        viewGuide.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        view.bottomAnchor.constraint(equalTo: viewWinning.bottomAnchor).isActive = true
        view.safeAreaLayoutGuide.trailingAnchor.constraint(equalTo: headLabel.trailingAnchor).isActive = true
        viewVideo.topAnchor.constraint(equalTo: headLabel.bottomAnchor).isActive = true
        view.safeAreaLayoutGuide.trailingAnchor.constraint(equalTo: viewGesture.trailingAnchor).isActive = true
        viewGesture.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        
        stackView.centerXAnchor.constraint(equalTo: viewWinning.centerXAnchor).isActive = true
        stackView.centerYAnchor.constraint(equalTo: viewWinning.centerYAnchor).isActive = true
        
        nextBtn.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        imageView.heightAnchor.constraint(equalToConstant: 150).isActive = true
        
        instrucLabel.centerYAnchor.constraint(equalTo: viewGuide.centerYAnchor).isActive = true
        letsFeedBtn.topAnchor.constraint(equalTo: instrucLabel.bottomAnchor, constant: 7.5).isActive = true
        letsFeedBtn.centerXAnchor.constraint(equalTo: viewGuide.centerXAnchor).isActive = true
        instrucLabel.centerXAnchor.constraint(equalTo: viewGuide.centerXAnchor).isActive = true
        
        letsFeedBtn.heightAnchor.constraint(equalToConstant: 50).isActive = true
        letsFeedBtn.widthAnchor.constraint(equalToConstant: 100).isActive = true
        
        instrucLabel.heightAnchor.constraint(greaterThanOrEqualToConstant: 21).isActive = true
        
        headLabel.heightAnchor.constraint(equalToConstant: 120).isActive = true
        
        view2.heightAnchor.constraint(equalToConstant: 120).isActive = true
        
        foodOne.leadingAnchor.constraint(equalTo: viewGesture.leadingAnchor, constant: 20).isActive = true
        foodThird.widthAnchor.constraint(equalTo: viewGesture.widthAnchor, multiplier: 0.134058).isActive = true
        foodSecond.leadingAnchor.constraint(equalTo: foodOne.trailingAnchor, constant: 7.5).isActive = true
        foodThird.leadingAnchor.constraint(equalTo: foodSecond.trailingAnchor, constant: 7.5).isActive = true
        viewGesture.bottomAnchor.constraint(equalTo: foodSixth.bottomAnchor).isActive = true
        foodSixth.leadingAnchor.constraint(equalTo: foodFivth.trailingAnchor, constant: 7.5).isActive = true
        foodSixth.widthAnchor.constraint(equalTo: viewGesture.widthAnchor, multiplier: 0.134058).isActive = true
        viewGesture.bottomAnchor.constraint(equalTo: foodThird.bottomAnchor).isActive = true
        foodSecond.widthAnchor.constraint(equalTo: viewGesture.widthAnchor, multiplier: 0.135266).isActive = true
        foodFourth.widthAnchor.constraint(equalTo: viewGesture.widthAnchor, multiplier: 0.134058).isActive = true
        foodFourth.leadingAnchor.constraint(equalTo: foodThird.trailingAnchor, constant: 7.5).isActive = true
        foodFivth.widthAnchor.constraint(equalTo: viewGesture.widthAnchor, multiplier: 0.135266).isActive = true
        viewGesture.bottomAnchor.constraint(equalTo: foodSecond.bottomAnchor).isActive = true
        viewGesture.bottomAnchor.constraint(equalTo: foodFivth.bottomAnchor).isActive = true
        viewGesture.bottomAnchor.constraint(equalTo: foodOne.bottomAnchor).isActive = true
        viewGesture.bottomAnchor.constraint(equalTo: foodFourth.bottomAnchor).isActive = true
        foodFivth.leadingAnchor.constraint(equalTo: foodFourth.trailingAnchor, constant: 7.5).isActive = true
        foodOne.widthAnchor.constraint(equalTo: viewGesture.widthAnchor, multiplier: 0.134058).isActive = true
        
        foodOne.widthAnchor.constraint(equalTo: foodOne.heightAnchor, multiplier: 55 / 57).isActive = true
        
        foodSixth.widthAnchor.constraint(equalTo: foodSixth.heightAnchor, multiplier: 55 / 57).isActive = true
        
        foodFivth.widthAnchor.constraint(equalTo: foodFivth.heightAnchor, multiplier: 56 / 57).isActive = true
        
        foodFourth.widthAnchor.constraint(equalTo: foodFourth.heightAnchor, multiplier: 55 / 57).isActive = true
        
        foodThird.widthAnchor.constraint(equalTo: foodThird.heightAnchor, multiplier: 55 / 57).isActive = true
        
        foodSecond.widthAnchor.constraint(equalTo: foodSecond.heightAnchor, multiplier: 56 / 57).isActive = true
        
        viewVideo.widthAnchor.constraint(equalToConstant: 400).isActive = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        playVideos()
    }
    
    fileprivate func initialSetup() {
        foodArray = [foodOne,foodSecond,foodThird,foodFourth,foodFivth,foodSixth]
        let foodName = ["apple","burger","fries","corn","avocado","soda"]
        let isGoodFood = [true,false,false,true,true,false]
        for i in 0..<foodArray.count {
            foodArray[i].isGoodFood = isGoodFood[i]
            foodArray[i].image = UIImage(named: foodName[i])
            foodArray[i].backgroundColor = .clear
        }
        
        let gesture = UIPanGestureRecognizer()
        gesture.addTarget(self, action: #selector(handlePanGesture(sender:)))
        viewGesture.addGestureRecognizer(gesture)
        viewGesture.isUserInteractionEnabled = true
    }
    
    func playVideos() {
        let filepath: String? = Bundle.main.path(forResource: "open", ofType: "mov")
        let fileURL = URL.init(fileURLWithPath: filepath!)
        avPlayer = AVQueuePlayer(url: fileURL)
        let playerLayer = AVPlayerLayer(player: avPlayer)
        playerLayer.backgroundColor = UIColor.clear.cgColor
        viewVideo.layoutIfNeeded()
        playerLayer.frame = viewVideo.bounds
        self.viewVideo.layer.addSublayer(playerLayer)
    }
    
    @objc func actionLetsFeed(_ sender: Any) {
        viewGuide.isHidden = true
    }
    
    func disableFood() {
        for food in foodArray {
            food.alpha = 0.5
        }
    }
    
    func enableFood() {
        for food in foodArray {
            food.alpha = 1
        }
    }
    @objc func actionNextStep(_ sender: Any) {
        winingCompletiom()
    }
    
    fileprivate func playGoodFood() {
        let filepath: String? = Bundle.main.path(forResource: "goodfood", ofType: "mov")
        let fileURL = URL.init(fileURLWithPath: filepath!)
        self.avPlayer.pause()
        avPlayer.removeAllItems()
        avPlayer.insert(AVPlayerItem(url: fileURL), after: nil)
        avPlayer.play()
        avPlayer.isMuted = true
        self.view.isUserInteractionEnabled = false
    }
    
    fileprivate func playJunkFood() {
        let filepath: String? = Bundle.main.path(forResource: "junkfood", ofType: "mov")
        let fileURL = URL.init(fileURLWithPath: filepath!)
        self.avPlayer.pause()
        avPlayer.removeAllItems()
        avPlayer.insert(AVPlayerItem(url: fileURL), after: nil)
        avPlayer.isMuted = true
        avPlayer.play()
        self.view.isUserInteractionEnabled = false
    }
    
    fileprivate func resetVideoGirl() {
        self.enableFood()
        self.view.isUserInteractionEnabled = true
        let filepath: String? = Bundle.main.path(forResource: "open", ofType: "mov")
        let fileURL = URL.init(fileURLWithPath: filepath!)
        self.avPlayer.pause()
        self.avPlayer.isMuted = true
        self.avPlayer.removeAllItems()
        self.avPlayer.insert(AVPlayerItem(url: fileURL), after: nil)
    }
    
    @objc func handlePanGesture(sender: UIPanGestureRecognizer) {
        switch sender.state {
        case .began, .changed:
            if sender.state == .began {
                let points = sender.location(in: viewGesture)
                for food in foodArray {
                    if viewGesture.convert(food.frame, from:viewGesture).contains(points) {
                        currentFood = food
                        isCurrentFood = true
                        break
                    }
                }
            }
            if !isCurrentFood { return }
            let yPint  = viewGesture.frame.height - sender.location(in: viewGesture).y
            let percent = (100.0 * yPint)/viewGesture.frame.height
            let saclePoint = percent/100
            currentFood?.transform =  .init(scaleX: 1.2 - saclePoint, y: 1.2 - saclePoint)
            currentFood?.frame.origin = sender.location(in: viewGesture)
            let time = (26.0 * percent)/100
            avPlayer.seek(to: CMTimeMake(value: Int64(time), timescale: 1))
        default:
            isCurrentFood = false
            if currentFood == nil {return}
            if currentFood!.frame.origin.y <= 80 {
                if currentFood?.isGoodFood ?? false {
                    playGoodFood()
                    disableFood()
                    DispatchQueue.main.asyncAfter(deadline: .now()+6) {
                        self.resetVideoGirl()
                        self.goodFoodCount += 1
                        self.currentFood = nil
                    }
                    self.currentFood?.isHidden = true
                } else {
                    playJunkFood()
                    disableFood()
                    DispatchQueue.main.asyncAfter(deadline: .now()+5) {
                        self.resetVideoGirl()
                        self.currentFood = nil
                    }
                    self.currentFood?.frame = self.currentFood?.initialFrame ?? .zero
                    self.currentFood?.transform = .init(scaleX: 1, y: 1)
                    self.view.layoutIfNeeded()
                }
            } else {
                self.currentFood?.frame = self.currentFood?.initialFrame ?? .zero
                self.currentFood?.transform = .init(scaleX: 1, y: 1)
                resetVideoGirl()
            }
            avPlayer.seek(to: CMTimeMake(value: Int64(0), timescale: 1))
        }
    }
}


class FoodView: UIImageView {
    var isGoodFood = false
    var initialFrame: CGRect = .zero
    override func awakeFromNib() {
        initialFrame = frame
    }
}


struct FoodViewVC: UIViewControllerRepresentable {
    @Binding var isComplete: Bool
    
    func makeUIViewController(context: Context) -> FoodViewController {
        let foodVC =  FoodViewController()
        foodVC.winingCompletiom = {
            self.isComplete = true
        }
        return foodVC
    }
    
    func updateUIViewController(_ uiViewController: FoodViewController, context: Context) {
    }
    typealias UIViewControllerType = FoodViewController
    
}
