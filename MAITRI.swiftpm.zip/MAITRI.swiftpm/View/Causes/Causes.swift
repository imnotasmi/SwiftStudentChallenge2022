import SwiftUI

struct Causes: View {
    @State var stateManagerArray:[Bool] = {
        var boolArray: [Bool] = (0...5).map { _ in return true }
        
        return boolArray
    }()
    @State var isPushNext = false
    let content = ["Excessive insulin",
                   "Lack of good quality sleep",
                   "Faulty or poor lifestyle",
                   "Presence of chemical pollutants in body",
                   "low-grade inflammation",
                   "Wrong diet"]
    
    private var gridItemLayout = [GridItem(.flexible()), GridItem(.flexible())]
    let cardWidth = UIScreen.main.bounds.width/2.5
    let cardHight = UIScreen.main.bounds.height/4.3
    var body: some View {
        ZStack {
            Rectangle()
                .fill(Theme.themeColor)
            VStack(alignment: .center){
                Text("CAUSES")
                    .font(Font.system(size:50, design: .monospaced))
                    .fontWeight(.black)
                    .foregroundColor(Theme.themeBlack)
                    .padding(10)
                    .scaledToFill()
                Text("Let's help Anna to find the cause of PCOS and PCOD")
                    .font(Font.system(size:28, design: .monospaced))
                    .fontWeight(.medium)
                    .lineLimit(nil)
                    .frame(width: UIScreen.main.bounds.width - 100)
                    .foregroundColor(Theme.themeBlack)
                    .padding(10)
                LazyVGrid(columns: gridItemLayout, spacing: 20) {
                    ForEach((0...5), id: \.self) {
                        Card(isFlipped: $stateManagerArray[$0], text: content[$0], width: cardWidth, height: cardHight)
                    }
                }
                NavigationLink(destination: Excercise(),
                               isActive: self.$isPushNext) {
                    EmptyView()
                }.hidden()
                Spacer(minLength: 10)
                if !stateManagerArray.contains(true) {
                    ZStack{
                        Rectangle()
                            .fill(Color(UIColor(red: 195/255, green: 153/255, blue: 156/255, alpha: 1)))
                        NavigationLink {
                            FoodViewVC(isComplete: $isPushNext)
                                .navigationBarTitle("")
                                .navigationBarHidden(true)
                        } label: {
                            Text("Next Step")
                                .font(Font.system(size:20, design: .rounded))
                                .fontWeight(.bold)
                                .foregroundColor(Color.white)
                            
                        }
                    }
                }
            }
        }.navigationBarTitle("")
            .navigationBarHidden(true)
    }
}

struct Causes_Previews: PreviewProvider {
    static var previews: some View {
        Causes()
    }
}


struct CardFront : View {
    let width : CGFloat
    let height : CGFloat
    var text: String
    @Binding var degree : Double
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 20)
                .fill(LinearGradient(gradient: Gradient(colors: [Color(UIColor(red: 173/255, green: 124/255, blue: 147/255, alpha: 1)), Color(UIColor(red: 195/255, green: 153/255, blue: 156/255, alpha: 1))]), startPoint: .leading, endPoint: .trailing))
                .frame(width: width, height: height)
                .shadow(color: .gray, radius: 2, x: 0, y: 0)
            Text(text)
                .font(Font.system(size:40, design: .rounded))
                .fontWeight(.heavy)
                .lineLimit(nil)
                .foregroundColor(Color.white)
                .padding(40)
        }.rotation3DEffect(Angle(degrees: degree), axis: (x: 0, y: 1, z: 0))
    }
}

struct CardBack : View {
    let width : CGFloat
    let height : CGFloat
    @Binding var degree : Double
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 20)
                .fill(LinearGradient(gradient: Gradient(colors: [Color(UIColor(red: 173/255, green: 124/255, blue: 147/255, alpha: 1)), Color(UIColor(red: 195/255, green: 153/255, blue: 156/255, alpha: 1))]), startPoint: .leading, endPoint: .trailing))
                .frame(width: width, height: height)
                .shadow(color: .gray, radius: 2, x: 0, y: 0)
            
        }.rotation3DEffect(Angle(degrees: degree), axis: (x: 0, y: 1, z: 0))
    }
}



struct Card: View {
    //MARK: Variables
    @State var backDegree = 0.0
    @State var frontDegree = -90.0
    @Binding var isFlipped:Bool
    var text: String
    var width : CGFloat
    var height : CGFloat
    let durationAndDelay : CGFloat = 0.3
    
    //MARK: Flip Card Function
    func flipCard () {
        if isFlipped {
            withAnimation(.linear(duration: durationAndDelay)) {
                backDegree = 90
            }
            withAnimation(.linear(duration: durationAndDelay).delay(durationAndDelay)){
                frontDegree = 0
            }
        }
        isFlipped = false
    }
    //MARK: View Body
    var body: some View {
        ZStack {
            CardFront(width: width, height: height, text: text, degree: $frontDegree)
            CardBack(width: width, height: height, degree: $backDegree)
        }.onTapGesture {
            flipCard ()
        }
    }
}
