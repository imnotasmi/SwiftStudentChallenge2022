import SwiftUI
struct Excercise: View {
    
    var activitys: [PysicalActivicty] {
        get {
            self.createDummyData()
        }
    }
    @State var isPushNext = false
    
    var body: some View {
        VStack {
            Text("Activity")
                .font(Font.system(size:50, design: .monospaced))
                .fontWeight(.black)
                .foregroundColor(Theme.themeBlack)
                .padding(10)
                .scaledToFill()
            
            Text("Things need to do!")
                .font(Font.system(size:30, design: .monospaced))
                .fontWeight(.black)
                .foregroundColor(Theme.themeBlack)
                .padding(10)
                .scaledToFill()
            
            NavigationLink(destination: Kudos(),
                           isActive: self.$isPushNext) {
                EmptyView()
            }.hidden()
            
            ZStack {
                Rectangle()
                    .fill(Theme.themeColor)
                VStack(alignment: .center ){
                    ForEach(activitys, id: \.self) { activity in
                        HStack(alignment: .center){
                            Image(activity.image)
                                .resizable()
                                .frame(width: 100, height: 100)
                                .padding(20)
                            VStack(alignment: .leading) {
                                Text(activity.name)
                                    .font(Font.system(size:32, design: .rounded))
                                    .fontWeight(.bold)
                                    .lineLimit(nil)
                                    .foregroundColor(Theme.themeBlack)
                                    .padding(10)
                                Text(activity.discription)
                                    .font(Font.system(size:20, design: .rounded))
                                    .fontWeight(.medium)
                                    .lineLimit(nil)
                                    .foregroundColor(Theme.themeBlack)
                                    .padding(10)
                                Spacer()
                            }
                        }
                        .background(Theme.themeColor)
                        .frame(width: UIScreen.main.bounds.width - 100)
                        .cornerRadius(20)
                        .shadow(radius: 10)
                        .padding(10)
                        
                    }
                    ZStack{
                        Rectangle()
                            .fill(Color(UIColor(red: 195/255, green: 153/255, blue: 156/255, alpha: 1)))
                        NavigationLink {
                            Kudos()
                                .navigationBarTitle("")
                                .navigationBarHidden(true)
                        } label: {
                            Text("Next")
                                .font(Font.system(size:20, design: .rounded))
                                .fontWeight(.bold)
                                .foregroundColor(Color.white)
                            
                        }
                    }.frame(height:100)
                }
                
            }
        }.background(Theme.themeColor)
            .navigationBarTitle("")
            .navigationBarHidden(true)
    }
    
    func createDummyData() -> [PysicalActivicty] {
        [.init(name: "Yoga", image: "yoga", discription: "It has been observed that yoga can help open up the pelvic area and also release deeply stored stress and promote relaxation of the mind and body."),
         .init(name: "Sleep", image: "sleep", discription: "Poor sleep quality is associated with an increased risk of obesity and insulin resistance which plays a key role in PCOS & PCOD."),
         .init(name: "Exercise", image: "excersice", discription: "Moderate exercise like brisk walking,cardio,jogging, cycling or swimming are all great activities that can help with PCOS & PCOD.")
        ]
    }
    
}

struct PysicalActivicty: Hashable{
    let id = UUID().uuidString
    var name: String
    var image: String
    var discription: String
}


struct Excercise_Previews: PreviewProvider {
    static var previews: some View {
        Excercise()
    }
}
