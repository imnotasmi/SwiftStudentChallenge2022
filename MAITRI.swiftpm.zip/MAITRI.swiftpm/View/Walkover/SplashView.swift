import SwiftUI

struct SplashView: View {

    var bigSize: CGFloat = {
        let sizeOfDevice = UIScreen.main.bounds
        return max(sizeOfDevice.width, sizeOfDevice.height)
    }()
    
    @State var scaleFactor: CGFloat = 1
    @State var isPushNext: Bool = false

    var body: some View {
        ZStack(alignment: .center) {
            GeometryReader { geo in
                NavigationLink(destination: WhatisPCOS(),
                               isActive: self.$isPushNext) {
                    EmptyView()
                }.hidden()
                Rectangle().fill(Theme.themeColor)
                    .edgesIgnoringSafeArea(.all)
                Rectangle().fill(Theme.themePink).frame(width: geo.size.width * 1.5, height: geo.size.width * 1.5, alignment: .center)
                    .cornerRadius((geo.size.width * 1.5)/2)
                    .edgesIgnoringSafeArea(.all)
                    .offset(
                        x: (geo.size.width - geo.size.width * 1.5)/2 ,
                        y: ((geo.size.height - geo.size.width * 1.5)/2) - (geo.size.width * 1.5)/2
                    )
            }
            VStack(alignment:.center){
                Spacer()
                Image("Hii")
                    .resizable()
                    .frame(width: 300, height: 300, alignment: .center)
                Text("MAITRI")
                    .font(Font.system(size:60, design: .monospaced))
                    .fontWeight(.heavy)
                    .foregroundColor(Theme.themeBlack)
                    .multilineTextAlignment(.center)
                    .frame(width: 300)
                //Spacer()
                Text("WOMAN'S HEALTH")
                    .font(Font.system(size:30, design: .monospaced))
                    .fontWeight(.heavy)
                    .foregroundColor(Theme.themeBlack)
                    .multilineTextAlignment(.center)
                    .frame(width: 300)
                Spacer()
            }.offset(x: 0, y: -80)
            
        }.onAppear{
            DispatchQueue.main.asyncAfter(deadline: .now()+3) {
                isPushNext = true
            }
        }
    }
    
    func getMax(_ size: CGSize) -> CGFloat {
        max(size.width, size.height)
    }
}

struct SplashView_Previews: PreviewProvider {
    static var previews: some View {
        SplashView()
            .previewInterfaceOrientation(.portraitUpsideDown)
        SplashView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
