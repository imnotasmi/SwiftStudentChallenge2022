import SwiftUI

struct Problems: View {
    

    @State var moveOnCicularPath = false
    @State var isPushNext = false

    let problem = [
        "Acne",
        "Excessive hair growth",
        "Menstural Irregularity",
        "Trouble Losing Weight",
    ]
    
    let ofSet: [CGPoint] = [
        CGPoint(x: -100.0, y: -200.0),
        CGPoint(x: 200.0, y: -200.0),
        CGPoint(x: -200.0, y: 100.0),
        
        CGPoint(x: 200.0, y: 200.0)
    ]
    
    var body: some View {
        ZStack {
            NavigationLink(destination: HealHer(),
               isActive: self.$isPushNext) {
                 EmptyView()
            }.hidden()
            Rectangle()
                .fill(Theme.themeColor)
            VStack(alignment:.center) {
                
                Text("Anna is facing a lot of problems!")
                    .font(Font.system(size:40, design: .monospaced))
                    .fontWeight(.black)
                    .lineLimit(nil)
                    .frame(width: UIScreen.main.bounds.width - 100)
                    .foregroundColor(Theme.themeBlack)
                    .padding(10)
                Spacer()
                
                ZStack {
                    ForEach(0..<4) {
                        Bubble(text: problem[$0], onMoving: $moveOnCicularPath)
                            .frame(width: 100, height: 100, alignment: .center)
                            .offset(x: ofSet[$0].x ,y: ofSet[$0].y)
                            .rotation3DEffect(.degrees(moveOnCicularPath ? 0 : 360), axis: (x: 0, y: 0, z: 100))
                            .onAppear {
                                withAnimation(.easeOut(duration: 8)) {
                                    self.moveOnCicularPath = true
                                }
                            }
                    }
                    VideoPlayer()
                        .frame(width: 400, height: 400, alignment: . center)
                }
                
                Spacer()
                ZStack(alignment: .trailing){
                    Rectangle().fill(.clear).frame(height: 60)
                    Button {
                        isPushNext = true
                    } label: {
                        Text("Next")
                            .font(Font.system(size:20, design: .rounded))
                            .bold()
                            .frame(width: 100, height: 60, alignment: .center)
                            .background(Theme.themePink)
                            .cornerRadius(10)
                            .padding(40)
                    }
                    .buttonStyle(.plain)
                }.scaledToFill()
            }
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now()+10) {
                isPushNext = true
            }
        }
        .navigationBarHidden(true)
    }
}

struct Problems_Previews: PreviewProvider {
    static var previews: some View {
        Problems()
    }
}
