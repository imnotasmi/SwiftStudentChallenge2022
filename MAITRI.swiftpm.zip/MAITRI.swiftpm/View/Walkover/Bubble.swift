import SwiftUI

struct Bubble: View {
    var text: String
    @Binding var onMoving: Bool
    var body: some View {
        ZStack(alignment: .center){
            Circle()
                .fill(LinearGradient(gradient: Gradient(colors: [Color(UIColor(red: 173/255, green: 124/255, blue: 147/255, alpha: 1)), Color(UIColor(red: 195/255, green: 153/255, blue: 156/255, alpha: 1))]), startPoint: .leading, endPoint: .trailing) )
           
                .scaledToFill()
            Text(text)
                .font(.headline)
                .fontWeight(.semibold)
                .foregroundColor(Color.white)
                .multilineTextAlignment(.center)
                .lineLimit(0)
                .scaledToFill()
                .padding(20)
                .rotationEffect(.degrees(onMoving ?  0 : -360 ))
                .animation(.easeOut(duration: 8), value: onMoving)

        }
    }
}
