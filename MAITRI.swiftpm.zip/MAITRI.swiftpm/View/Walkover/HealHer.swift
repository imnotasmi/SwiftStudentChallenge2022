import SwiftUI

struct HealHer: View {
    
    @State var moveOnCicularPath = false
    @State var isPushNext = false
    
    let images = [
        "dumbbell",
        "search",
        "avocado",
        "alert"
    ]
    
    let ofSet = [
        CGPoint(x: -200.0, y: -200.0),
        CGPoint(x: 200.0, y: -200.0),
        CGPoint(x: -200.0, y: 200.0),
        CGPoint(x: 200.0, y: 200.0)
    ]
    
    var body: some View {
        ZStack {
            NavigationLink(destination: Causes(),
                           isActive: self.$isPushNext) {
                EmptyView()
            }.hidden()
            VStack {
                ZStack {
                    Rectangle()
                        .fill(Theme.themeColor)
                    ForEach(0..<4) {
                        RoatedImage(name: images[$0], onMoving: $moveOnCicularPath)
                            .offset(x: ofSet[$0].x ,y: ofSet[$0].y)
                            .rotation3DEffect(.degrees(moveOnCicularPath ? 0 : -360), axis: (x: 0, y: 0, z: 100))
                            .onAppear {
                                withAnimation(.linear(duration: 10)) {
                                    self.moveOnCicularPath = true
                                }
                            }
                    }
                    VStack {
                        Image("heal")
                            .resizable()
                            .frame(width: 200, height: 200, alignment: .center)
                        Text("Help Anna to heal!")
                            .font(Font.system(size:40, design: .rounded))
                            .fontWeight(.heavy)
                            .lineLimit(nil)
                            .foregroundColor(Theme.themeBlack)
                            .padding(40)
                    }
                    
                }
                ZStack(alignment: .trailing){
                    Rectangle().fill(Theme.themeColor).frame(height: 60)
                    Text("Next")
                        .font(Font.system(size:20, design: .rounded))
                        .bold()
                        .frame(width: 100, height: 60, alignment: .center)
                        .background(Theme.themePink)
                        .cornerRadius(10)
                        .padding(40)
                        .onTapGesture {
                            isPushNext = true
                        }
                }.background(Theme.themeColor)
                    .scaledToFill()
            }
            
        }.background(Theme.themeColor)
        .navigationBarTitle("")
            .navigationBarHidden(true)
            .onAppear{
                DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                    isPushNext = true
                }
            }
    }
}

struct HealHer_Previews: PreviewProvider {
    static var previews: some View {
        HealHer()
    }
}


struct RoatedImage: View {
    var name: String
    @Binding var onMoving: Bool
    var body: some View {
        ZStack(alignment: .center){
            Image(name)
                .resizable()
                .frame(width: 100, height: 100, alignment: .center)
                .padding(20)
                .rotationEffect(.degrees(onMoving ?  0 : 360 ))
        }
    }
}





