import SwiftUI

struct WhatisPCOS: View {

    @State var showAnimation: Bool = false

    let whatis: String = "Polycystic Ovarian Syndrome (PCOS), Polycystic Ovarian Disease (PCOD) is an extremely common hormonal disorder in women nowadays.It is a medical condition in women, where the ovaries produce multiple immature eggs which, over time, become cysts on the ovaries."
    let prapostion = "1 in 10 women suffer from PCOS. About 50% patients are undiagnosed, that is, they are unaware that they have PCOD."

    var body: some View {
        ZStack {
            Rectangle()
                .fill(Theme.themeColor)
                .edgesIgnoringSafeArea(.all)
            ScrollView {
                VStack(alignment: .leading){
                    
                    if showAnimation {
                        Text("WHAT IS PCOS & PCOD?")
                            .font(Font.system(size:50, design: .monospaced))
                            .fontWeight(.black)
                            .foregroundColor(Theme.themeBlack)
                            .padding(40)
                            .scaledToFill()
                            .transition(.scale)
                        Text(whatis)
                            .font(Font.system(size:40, design: .rounded))
                            .fontWeight(.heavy)
                            .lineLimit(nil)
                            .foregroundColor(Theme.themePink)
                            .padding(40)
                            .transition(.slide)
                        Text(prapostion)
                            .font(Font.system(size:30, design: .rounded))
                            .fontWeight(.heavy)
                            .lineLimit(nil)
                            .foregroundColor(Theme.themePink)
                            .padding(40)
                            .transition(.slide)
                    }
                    ZStack(alignment: .trailing){
                        Rectangle().fill(.clear).frame(height: 60)
                        NavigationLink {
                            Problems()
                        } label: {
                            Text("Next")
                                .font(Font.system(size:20, design: .rounded))
                                .bold()
                                .frame(width: 100, height: 60, alignment: .center)
                                .background(Theme.themePink)
                                .cornerRadius(10)
                                .padding(40)
                        }
                        .buttonStyle(.plain)
                    }.scaledToFill()
                    Spacer()
                }
            }
            
        }.navigationBarTitle("")
            .navigationBarHidden(true)
            .onAppear {
                withAnimation(.easeIn(duration: 1.5)) {
                    showAnimation = true
                }
        }
    }
}

struct WhatisPCOS_Previews: PreviewProvider {
    static var previews: some View {
        WhatisPCOS()
    }
}
