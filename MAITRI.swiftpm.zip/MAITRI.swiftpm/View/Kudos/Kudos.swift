
import SwiftUI
import AVFoundation

var player: AVAudioPlayer!

struct Kudos: View {
    @State var wish = false
    @State var finishWish = false
    
    var body: some View {
        
        ZStack{
            VStack(spacing: 30){
                Image("kudos")
                    .resizable()
                    .aspectRatio (contentMode: .fit)
                    .frame (height: getRect().width / 1.8)
                
                Text("You have done a great Job in helping ANNA!")
                    .font(.custom("Limelight-Regular", size: 35))
                    .kerning (3)
                    .lineSpacing (10.0)
                    .foregroundColor(Theme.themeBlack)
                    .multilineTextAlignment (.center)
                
                Button (action: doAnimation, label: {
                    Text("kudos")
                        .kerning (2)
                        .padding (.vertical,12)
                        .padding (.horizontal,50)
                        .background(Color(UIColor(red: 195/255, green: 153/255, blue: 156/255, alpha: 1)))
                        .foregroundColor(.white)
                })
                .disabled(wish)
            }
            EmitterView()
                .scaleEffect(wish ? 1 : 0, anchor: .top)
                .opacity(wish && !finishWish ? 1 : 0)
                .offset(y: wish ? 0 : getRect().height / 2)
                .ignoresSafeArea()
        }
        .background(Theme.themeColor)
        .navigationBarHidden(true)
       
        
    }
    
    
    
    func doAnimation(){
        let url = Bundle.main.url(forResource: "cheers_sound", withExtension: "mp3")
        guard url != nil else{
            return
        }
        do{
            player = try AVAudioPlayer(contentsOf: url!)
            player?.play()
        }catch{
            
        }
        
        withAnimation(.spring()){
            wish = true
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now()+3){
            withAnimation(.easeInOut(duration: 1.5)){
                finishWish = true
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                finishWish = false
                wish = false
            }
        }
    }
    
}



func getRect()->CGRect{
    return UIScreen.main.bounds
}

struct EmitterView: UIViewRepresentable {
    
    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        view.backgroundColor = .clear
        
        let emitterLayer = CAEmitterLayer()
        emitterLayer.emitterShape = .line
        emitterLayer.emitterCells = createEmiterCells()
        
        emitterLayer.emitterSize = CGSize(width: getRect().width, height: 1)
        emitterLayer.emitterPosition = CGPoint(x:getRect().width / 2, y: 0 )
        view.layer.addSublayer(emitterLayer)
        return view
    }
    
    func updateUIView(_ uiView: UIView, context: Context) {}
    
    func createEmiterCells ()->[CAEmitterCell]{
        
        var emitterCells: [CAEmitterCell] = []

        
        for index in 1...12{
            let cell = CAEmitterCell()
            cell.contents = UIImage(named: getImage(index: index))?.cgImage
            cell.color = getColor().cgColor
            cell.birthRate = Float.random(in: 2...4.5)
            cell.lifetime = Float.random(in: 20...25)
            cell.velocity = CGFloat.random(in: 150...200)
            cell.scale = 0.2
            cell.emissionLongitude = .pi
            cell.emissionRange = 0.5
            cell.spin = CGFloat.random(in: 2...4)
            cell.spinRange = 1
            emitterCells.append(cell)
        }
        
        return emitterCells
        
    }
    
    func getColor() -> UIColor {
        let colors : [UIColor] = [.systemPink,.systemGreen,.systemRed,.systemBlue,.systemOrange,.systemPurple]
        return colors.randomElement()!
    }
    

    
    func getImage(index: Int)->String{
        if (index<4){
            return "square"
        }else if index>5 && index <= 8{
            return "circle"
        }
        else{
            return "triangle"
        }
    }
    
}

struct Kudos_Previews: PreviewProvider {
    static var previews: some View {
        Kudos()
    }
}
